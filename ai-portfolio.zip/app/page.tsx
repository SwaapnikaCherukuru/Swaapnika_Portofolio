import { HeroSection } from "@/components/hero-section"
import { Projects } from "@/components/projects"
import { ContactForm } from "@/components/contact-form"

export default function Home() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <Projects />
      <ContactForm />
    </main>
  )
}
