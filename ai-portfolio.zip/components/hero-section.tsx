import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Futuristic Background - Updated with modern blue-purple gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-indigo-800 to-purple-900 z-0">
        {/* Geometric Pattern Overlay */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_600px_at_50%_20%,rgba(120,119,255,0.4),transparent)]"></div>
          <div className="grid grid-cols-12 h-full">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="h-full border-r border-white/5"></div>
            ))}
          </div>
          <div className="grid grid-rows-12 w-full absolute top-0 left-0 h-full">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="w-full border-b border-white/5"></div>
            ))}
          </div>
        </div>

        {/* Animated Particles */}
        <div className="absolute inset-0">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-white/20"
              style={{
                width: `${Math.random() * 6 + 2}px`,
                height: `${Math.random() * 6 + 2}px`,
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                animation: `float ${Math.random() * 10 + 10}s linear infinite`,
                opacity: Math.random() * 0.5 + 0.3,
              }}
            ></div>
          ))}
        </div>

        {/* Glowing Accent */}
        <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-purple-500/20 to-transparent"></div>
      </div>

      {/* Content Container */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Name with Animated Underline - Increased font size */}
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-white tracking-tight">
            <span className="inline-block relative">
              Cherukuru Swaapnika Chowdary
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-blue-400 via-purple-500 to-blue-400 rounded-full animate-pulse"></span>
            </span>
          </h1>

          {/* Role with Glowing Effect */}
          <div className="relative">
            <p className="text-xl md:text-2xl text-blue-100 font-light">
              AI & GenAI Developer | MS in Information Systems @ Northeastern
            </p>
            <div className="absolute -inset-1 bg-blue-500/20 blur-xl opacity-30 rounded-full"></div>
          </div>

          {/* CTA Button - Enhanced with more prominent hover animation */}
          <div className="pt-8">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white border-none px-10 py-7 text-lg rounded-full transition-all duration-300 shadow-lg hover:shadow-purple-500/30 transform hover:scale-105 hover:translate-y-[-2px]"
            >
              Explore My Work
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 ml-2 transition-transform duration-300 group-hover:translate-x-1"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </Button>
          </div>
        </div>

        {/* Floating Tech Icons */}
        <div className="absolute bottom-16 left-0 right-0 flex justify-center gap-8 opacity-70">
          <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center">
            <span className="text-blue-200 text-xl">AI</span>
          </div>
          <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center">
            <span className="text-blue-200 text-xl">ML</span>
          </div>
          <div className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center">
            <span className="text-blue-200 text-xl">NLP</span>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-0 right-0 flex justify-center animate-bounce">
        <div className="w-8 h-12 rounded-full border-2 border-white/30 flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  )
}
