import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"
import { ProjectCard } from "./project-card"

// Sample project data
const projects = [
  {
    title: "CNN for Drug Resistance",
    description:
      "Used CNNs on bacterial genome sequences to discover noncoding motifs related to antibiotic resistance.",
    imageSrc: "/placeholder.svg?height=224&width=400",
    imageAlt: "CNN for Drug Resistance",
    tags: ["CNN", "Genomics"],
    accentColor: "blue" as const,
    svgPath:
      "M40,-51.2C51.2,-41.9,59.5,-28.7,63.3,-14.1C67.1,0.5,66.4,16.5,59.5,28.7C52.6,40.9,39.5,49.3,25.2,55.1C10.9,60.9,-4.7,64.1,-19.2,60.5C-33.7,56.9,-47.1,46.5,-55.2,32.9C-63.3,19.3,-66.1,2.5,-62.2,-12.2C-58.3,-26.9,-47.7,-39.5,-35.2,-48.7C-22.7,-57.9,-8.3,-63.7,3.7,-68.1C15.7,-72.5,28.8,-60.5,40,-51.2Z",
    overlayContent: (
      <div className="w-full h-12 relative overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute h-2 w-2 rounded-full bg-blue-400"
            style={{
              left: `${(i * 10) % 100}%`,
              top: `${Math.sin(i * 0.5) * 20 + 50}%`,
              opacity: i % 2 === 0 ? 0.8 : 0.4,
            }}
          ></div>
        ))}
      </div>
    ),
  },
  {
    title: "Leo – GenAI + VR Assistant",
    description: "Developed Leo, an AI-powered voice assistant integrated into Unity VR to enhance virtual learning.",
    imageSrc: "/placeholder.svg?height=224&width=400",
    imageAlt: "Leo – GenAI + VR Assistant",
    tags: ["GenAI", "VR", "Unity"],
    accentColor: "purple" as const,
    svgPath:
      "M47.7,-51.2C59.5,-42.9,65.8,-25.8,67.3,-8.8C68.9,8.2,65.8,25.2,56.2,37.8C46.6,50.5,30.6,58.8,13.7,63.1C-3.2,67.3,-21,67.5,-35.4,60.1C-49.8,52.7,-60.8,37.7,-67.4,20.1C-74,2.5,-76.2,-17.7,-68.5,-32.6C-60.8,-47.5,-43.2,-57.1,-26.6,-62.9C-10,-68.7,5.7,-70.7,19.9,-66.5C34.1,-62.3,46.8,-52,47.7,-51.2Z",
    overlayContent: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="w-24 h-24 text-purple-300"
      >
        <path d="M2 12.5c0 2.76 2.24 5 5 5 .71 0 1.39-.15 2-.42V12.5H2Z"></path>
        <path d="M17 12.5c0 2.76 2.24 5 5 5 .71 0 1.39-.15 2-.42V12.5H17Z"></path>
        <path d="M9 12.5v4.58c.61.27 1.29.42 2 .42s1.39-.15 2-.42V12.5H9Z"></path>
        <path d="M5 8.5h14v4H5v-4Z"></path>
      </svg>
    ),
  },
  {
    title: "Real-Time Lane Detection",
    description: "Built a lane detection model using OpenCV and PyTorch, trained on real road footage.",
    imageSrc: "/placeholder.svg?height=224&width=400",
    imageAlt: "Real-Time Lane Detection",
    tags: ["OpenCV", "PyTorch", "Computer Vision"],
    accentColor: "cyan" as const,
    svgPath:
      "M39.9,-48.2C51.1,-36.9,59.5,-23.7,64.1,-8.1C68.8,7.5,69.8,25.5,61.7,38.2C53.6,50.9,36.3,58.3,19.2,62.1C2.1,65.9,-14.9,66.1,-30.1,59.9C-45.4,53.7,-59,41.1,-65.2,25.8C-71.4,10.5,-70.3,-7.5,-63.3,-22.1C-56.3,-36.7,-43.5,-47.9,-29.9,-58C-16.3,-68,-8.2,-76.8,2.8,-80.1C13.7,-83.4,27.5,-81.1,39.9,-48.2Z",
    overlayContent: (
      <div className="w-full h-24 relative overflow-hidden">
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-yellow-400"></div>
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-yellow-400 transform -translate-y-10"></div>
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-yellow-400 transform translate-y-10"></div>
      </div>
    ),
  },
]

export function Projects() {
  return (
    <section className="py-24 bg-gradient-to-b from-slate-900 to-slate-950">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4 relative inline-block">
            Featured Projects
            <div className="absolute -bottom-3 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-purple-500"></div>
          </h2>
          <p className="text-blue-200/80 max-w-2xl mx-auto text-lg">
            Exploring the intersection of AI, machine learning, and real-world applications
          </p>
        </div>

        {/* Project Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} {...project} />
          ))}
        </div>

        {/* View All Projects Button */}
        <div className="mt-16 text-center">
          <Button className="bg-slate-800/80 hover:bg-slate-700/80 text-white border border-slate-700/50 px-8 py-6 text-lg rounded-full transition-all duration-300 backdrop-blur-sm shadow-md hover:shadow-lg hover:shadow-purple-500/10 transform hover:scale-105">
            View All Projects
            <ExternalLink className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  )
}
