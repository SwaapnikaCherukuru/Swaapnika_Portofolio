import type React from "react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { ArrowRight } from "lucide-react"

export interface ProjectCardProps {
  title: string
  description: string
  imageSrc: string
  imageAlt: string
  tags: string[]
  accentColor: "blue" | "purple" | "cyan"
  svgPath: string
  overlayContent?: React.ReactNode
}

export function ProjectCard({
  title,
  description,
  imageSrc,
  imageAlt,
  tags,
  accentColor,
  svgPath,
  overlayContent,
}: ProjectCardProps) {
  // Define color variants based on accentColor
  const colorVariants = {
    blue: {
      tagBg: "bg-blue-900/30",
      tagText: "text-blue-300",
      buttonText: "text-blue-400",
      buttonHover: "hover:text-blue-300 hover:bg-blue-900/30",
      shadow: "shadow-blue-900/20",
      hoverShadow: "hover:shadow-blue-500/20",
      titleHover: "group-hover:text-blue-400",
      overlay: "from-blue-600/20",
    },
    purple: {
      tagBg: "bg-purple-900/30",
      tagText: "text-purple-300",
      buttonText: "text-purple-400",
      buttonHover: "hover:text-purple-300 hover:bg-purple-900/30",
      shadow: "shadow-purple-900/20",
      hoverShadow: "hover:shadow-purple-500/20",
      titleHover: "group-hover:text-purple-400",
      overlay: "from-purple-600/20",
    },
    cyan: {
      tagBg: "bg-cyan-900/30",
      tagText: "text-cyan-300",
      buttonText: "text-cyan-400",
      buttonHover: "hover:text-cyan-300 hover:bg-cyan-900/30",
      shadow: "shadow-cyan-900/20",
      hoverShadow: "hover:shadow-cyan-500/20",
      titleHover: "group-hover:text-cyan-400",
      overlay: "from-cyan-600/20",
    },
  }

  const colors = colorVariants[accentColor]

  return (
    <div
      className={`group relative bg-slate-800/50 rounded-lg overflow-hidden border border-slate-700/50 backdrop-blur-sm transition-all duration-300 hover:transform hover:scale-[1.02] shadow-md ${colors.shadow} hover:shadow-xl ${colors.hoverShadow}`}
    >
      {/* Project Image */}
      <div className="relative h-56 overflow-hidden rounded-t-lg">
        <Image
          src={imageSrc || "/placeholder.svg"}
          alt={imageAlt}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent opacity-70"></div>

        {/* SVG Overlay */}
        <div className="absolute inset-0 opacity-30 mix-blend-screen">
          <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
            <path
              fill={accentColor === "blue" ? "#4F46E5" : accentColor === "purple" ? "#A855F7" : "#06B6D4"}
              d={svgPath}
              transform="translate(100 100)"
            />
          </svg>
        </div>

        {/* Custom Overlay Content */}
        {overlayContent && (
          <div className="absolute inset-0 flex items-center justify-center opacity-20">{overlayContent}</div>
        )}
      </div>

      {/* Content */}
      <div className="p-6 space-y-4">
        <h3 className={`text-xl font-bold text-white ${colors.titleHover} transition-colors`}>{title}</h3>
        <p className="text-slate-300">{description}</p>
        <div className="pt-4 flex justify-between items-center">
          <div className="flex flex-wrap gap-2">
            {tags.map((tag, index) => (
              <span key={index} className={`px-2 py-1 ${colors.tagBg} ${colors.tagText} text-xs rounded-full`}>
                {tag}
              </span>
            ))}
          </div>
          <Button variant="ghost" size="icon" className={`${colors.buttonText} ${colors.buttonHover}`}>
            <ArrowRight className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Hover Overlay */}
      <div
        className={`absolute inset-0 bg-gradient-to-t ${colors.overlay} via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300`}
      ></div>
    </div>
  )
}
